from project.animal import Animal

class Cheetah(Animal):
    money_for_care = 60