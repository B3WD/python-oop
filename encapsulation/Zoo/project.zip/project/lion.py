from project.animal import Animal

class Lion(Animal):
    money_for_care = 50